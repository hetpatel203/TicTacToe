import logo from './logo.svg';
import './App.css';
import Tictactoe from './Components/TicTacToe/Tictactoe';
function App() {
  return (
    <div className="App">
      <Tictactoe />
    </div>
  );
}

export default App;
